=== Fusion Plugins ===
Contributors:
Tags: plugins, catalogue, updates
Requires at least: 6.5
Requires PHP: 7.4
Stable tag: 0.4.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Curated annual plugin catalogs with convenient updates from the Fusion mirror.

== Description ==

Fusion Plugins offers a selected plugin for each function, organized in annual catalogs. Check the mirror, select available updates and install them from verified GitHub release ZIPs. Native WordPress plugin updates remain unchanged.

== Installation ==

Upload fusion-plugins.zip through Plugins > Add Plugin > Upload Plugin and activate it. On multisite, network activate it. Open Plugins > Fusion Plugins.

== Frequently Asked Questions ==

= Does Fusion replace WordPress updates? =

No. Native WordPress plugin update checks continue normally.

= Are premium plugins included in the mirror? =

Premium entries can be mirrored when a licensed ZIP is supplied and distribution is permitted. Until then, Fusion shows a WordPress update notice with a link to the Plugins screen when WordPress reports one.

== Changelog ==

= 0.4.2 =

* Put WordPress update links in an Actions column and simplify update details.

= 0.4.1 =

* Order the Plugins submenu as Techn, AlphaSys, Fusion and Other Plugins.

= 0.4.0 =

* Show WordPress update notices when a catalogue plugin has no mirrored update.
* Support verified manual mirroring of licensed vendor ZIPs.

= 0.3.3 =

* Use a new Fusion index so earlier controllers can still discover their own updates.

= 0.3.2 =

* Add eight Fusion 26 selections and mirror three public WordPress.org packages.

= 0.3.1 =

* Remove the redundant Manual checks only label from the controller status line.

= 0.3.0 =

* Include Fusion Plugins in its own catalogue and offer its verified release through Fusion updates.

= 0.2.2 =

* Show mirror checks and installation progress in an accessible modal.

= 0.2.1 =

* Remove the redundant Mirror column from Updates available.

= 0.2.0 =

* Add mirror checks, selected updates, grouped catalog cards and a catalog picker.
* Remove the Settings and separate Catalogs tabs.

= 0.1.1 =

* Show actionable updates only in the Updates available tab.

= 0.1.0 =

* Initial Fusion catalog controller and mirror approval workflow.
